package part;

/**
 * Interface for the Team class.
 */
public interface Iteam {
  void addPlayer(Player player);

  void buildTeam();

  String getAllPlayers();

  String getStartingLineup();
}
