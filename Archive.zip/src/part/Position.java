package part;

/**
 * Enum file.
 */
public enum Position {
  Goalie,
  Defenders,
  Midfielders,
  Forward;
}
